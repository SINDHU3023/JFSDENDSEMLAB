package klu.model;



public class Courses {
	String coursecode;
	String coursetitle;
	double credits;
	public String getCoursecode() {
		return coursecode;
	}
	public void setCoursecode(String coursecode) {
		this.coursecode = coursecode;
	}
	public String getCoursetitle() {
		return coursetitle;
	}
	public void setCoursetitle(String coursetitle) {
		this.coursetitle = coursetitle;
	}
	public double getCredits() {
		return credits;
	}
	public void setCredits(double credits) {
		this.credits = credits;
	}
	@Override
	public String toString() {
		return "Courses [coursecode=" + coursecode + ", coursetitle=" + coursetitle + ", credits=" + credits + "]";
	}

}
