package klu.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CourseManager {
	public String saveCouse(Courses C)throws Exception{
//		Class.forName("com.mysql.cj.jdbc.Driver");
//		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/jfsd17","root","Sindhu@2004");
//		PreparedStatement ps =con.prepareStatement("insert into courses values(?,?,?)");
//		ps.setString(1, C.getCoursecode());
//		ps.setString(2, C.getCoursetitle());
//		ps.setDouble(3, C.getCredits());
//		ps.execute();
		return "New course has been added";
		
		
	}

}
